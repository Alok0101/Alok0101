<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 50px;
        }
        .thankyou-message {
            font-size: 24px;
            color: #4CAF50;
        }
    </style>
</head>
<body>
    <div class="thankyou-message">
        <h1>Thank You for Your Message!</h1>
        <p>We have received your message and will get back to you shortly.</p>
    </div>
</body>
</html>
